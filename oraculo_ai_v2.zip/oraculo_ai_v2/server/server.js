import express from "express";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
dotenv.config();
const app=express();
const __dirname=path.dirname(fileURLToPath(import.meta.url));
app.use(express.json({limit:"12mb"}));
app.use(express.static(path.join(__dirname,"../web")));
app.get("/api/health",(req,res)=>res.json({ok:true,configured:Boolean(process.env.OPENAI_API_KEY)}));
app.post("/api/analyze",async(req,res)=>{
 try{
  if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:"Falta configurar OPENAI_API_KEY en el servidor."});
  const image=req.body?.image;
  if(typeof image!=="string"||!/^data:image\/(jpeg|png|webp);base64,/.test(image))return res.status(400).json({error:"Imagen no válida. Usá JPG, PNG o WEBP."});
  if(image.length>11_000_000)return res.status(413).json({error:"La imagen es demasiado grande."});
  const model=process.env.OPENAI_MODEL||"gpt-4.1-mini";
  const response=await fetch("https://api.openai.com/v1/responses",{
   method:"POST",
   headers:{"Authorization":`Bearer ${process.env.OPENAI_API_KEY}`,"Content-Type":"application/json"},
   body:JSON.stringify({
    model,
    tools:[{type:"web_search"}],
    instructions:"Sos ORÁCULO AI, asistente de investigación visual responsable. Analizá objetos, lugares, animales, productos, obras y documentos. No identifiques ni intentes identificar personas en imágenes, no hagas reconocimiento facial ni biométrico, no infieras atributos sensibles y no busques información íntima. Si aparecen personas, describí solo elementos no sensibles de la escena y enfocá el análisis en objetos o contexto. Separá observaciones de hipótesis. No inventes fuentes; cuando uses búsqueda web, cita páginas con título y URL si están disponibles. Indicá incertidumbre y sugerí verificaciones.",
    input:[{role:"user",content:[
     {type:"input_text",text:"Analizá esta imagen. Entregá: 1) descripción objetiva; 2) objetos/elementos reconocibles; 3) texto visible si lo hay; 4) posibles pistas de lugar, época o modelo solo si hay evidencia; 5) términos de búsqueda útiles; 6) fuentes públicas encontradas y qué respaldan; 7) límites e incertidumbre. No identifiques personas."},
     {type:"input_image",image_url:image,detail:"high"}
    ]}],
    max_output_tokens:1200
   })
  });
  const data=await response.json();
  if(!response.ok){const msg=data?.error?.message||"Error del proveedor de IA.";return res.status(response.status).json({error:msg});}
  const analysis=(data.output||[]).flatMap(x=>x.content||[]).filter(x=>x.type==="output_text").map(x=>x.text).join("\n\n");
  res.json({analysis:analysis||"No se recibió texto de análisis."});
 }catch(err){res.status(500).json({error:"Error interno al analizar la imagen. "+err.message});}
});
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`ORÁCULO AI listo en http://localhost:${port}`));
